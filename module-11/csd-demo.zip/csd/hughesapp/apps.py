from django.apps import AppConfig


class HughesappConfig(AppConfig):
    name = 'csd.hughesapp'
